import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function BrunchCasawiWebsite() {
  const slides = [
    {
      title: "Brunch Casawi",
      subtitle: "A Private Concept Experience in Casablanca",
      description: "A curated brunch experience blending local culture, music, and wellness in the heart of Morocco.",
    },
    {
      title: "The Concept",
      subtitle: "Not Just a Brunch. A Lifestyle.",
      description:
        "Brunch Casawi redefines weekends with a fusion of Mediterranean flavors, soulful DJs, and Instagrammable aesthetics. A place to connect, celebrate, and feel Casawi.",
    },
    {
      title: "Target Audience",
      subtitle: "Who We Serve",
      description:
        "Young professionals, creatives, and cosmopolitan locals aged 20–40 looking for unique lifestyle experiences that combine food, music, and social interaction.",
    },
    {
      title: "Experience Flow",
      subtitle: "A Typical Sunday at Brunch Casawi",
      description:
        "11AM – Arrival & Welcome Drink\n12PM – Brunch Buffet Opens\n2PM – Live DJ / Guest Performer\n4PM – Chillout & Networking\n6PM – Sunset Closing Ritual",
    },
    {
      title: "Visual Identity",
      subtitle: "Modern, Luxurious, Moroccan",
      description:
        "Colors: Sand, Mint, Gold\nStyle: Clean, warm, urban-chic\nElements: Mosaic patterns, palm shadows, ceramic tableware",
    },
    {
      title: "Location",
      subtitle: "Casablanca",
      description:
        "Indoor/outdoor venue with rooftop or garden potential. Centrally located, with strong visual appeal and audio setup.",
    },
    {
      title: "Let's Collaborate",
      subtitle: "Partners, DJs, Brands, Influencers",
      description:
        "We are actively seeking aligned partners for our soft launch. Let's co-create a new brunch culture in Morocco.",
    },
  ];

  return (
    <main className="min-h-screen bg-gradient-to-br from-white to-gray-100 py-12 px-4">
      <section className="max-w-5xl mx-auto space-y-16">
        {slides.map((slide, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="rounded-2xl shadow-xl border border-gray-200">
              <CardContent className="p-10 space-y-6">
                <h2 className="text-4xl font-bold tracking-tight text-gray-800">
                  {slide.title}
                </h2>
                <h3 className="text-2xl text-gray-600 italic">{slide.subtitle}</h3>
                <p className="text-lg text-gray-700 whitespace-pre-line">{slide.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
        <div className="flex justify-center">
          <Button className="mt-12 px-6 py-3 text-lg text-white bg-black hover:bg-gray-800 rounded-xl shadow-lg">
            Contact Us
          </Button>
        </div>
      </section>
    </main>
  );
}
